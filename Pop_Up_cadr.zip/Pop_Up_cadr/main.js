var In= $('.HW')
$('.cadr').hide();


In.on('mousedown', function () {
    In.css('color', 'white');
    In.css('background', 'orange');
    In.css('border', '2px solid white');
    $('.com').css('filter', 'blur(10px)');
    $('.com').css('user-select', 'none');
    
    $('.cadr').show();
});

In.on('mouseup', function () {
    In.css('color', 'orangered');
    In.css('background', 'white');
    In.css('border', '2px solid orange');
});

$('.closer').on('mousedown', function () {
    $('closer').css('color', 'white');
    $('closer').css('background', 'orange');
    $('closer').css('border', '2px solid white');
    $('.com').css('filter', 'blur(0px)');
    $('.com').css('user-select', 'none');
    $('.cadr').hide();
});

